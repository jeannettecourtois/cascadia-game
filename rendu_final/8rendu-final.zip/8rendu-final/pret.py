from ressource import *
from requeteSql import *

#    ("1.neuf")
#    ("2.bon")
#    ("3.abîmé")
#   ("4.perdu")


def choixExemplaire(filtreTitre=True, titre=""):
    if filtreTitre:
        titre = input("Donnez le titre (ou une partie ou rien) : ")
    if titre:
        sql = f"""
        SELECT e.id, r.titre, e.etat
        FROM Exemplaire e
        JOIN Ressources r ON e.CodeRessource = r.CodeRessource
        LEFT JOIN Pret p ON e.id = p.id_exp AND p.dateRendu IS NULL
        WHERE r.titre ILIKE '%{titre}%' 
        AND e.etat IN ('bon','neuf','trés bon','très bon') 
        AND p.id_exp IS NULL
        """
        #ILIKE = insensitive LIKE
        # AND e.etat IN ('bon','neuf') 
    else:
        sql = """
        SELECT e.id, r.titre, e.etat
        FROM Exemplaire e
        JOIN Ressources r ON e.CodeRessource = r.CodeRessource
        LEFT JOIN Pret p ON e.id = p.id_exp AND p.dateRendu IS NULL
        AND e.etat IN ('bon','neuf') 
        
        AND p.id_exp IS NULL
        """
        # WHERE e.etat IN ('bon', 'neuf')
    
    # Exécution de la requête SQL
    choix = executeSqlSelect(sql, ['id exp','titre','etat'],True,False)
    if choix[0]==-1 :
        print("Aucun exemplaire en bon état disponible ou choix invalide.")
        return None
    return choix [1]
    


def InsertPretSql(debut,duree,dateRendu,id_exp,id_adh):
    conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
    cursor = conn.cursor()
    
    if dateRendu :
        sql=f"""
                INSERT INTO Pret (debut, duree, dateRendu, id_exp, id_adh) 
                VALUES ('{debut}', {duree}, '{dateRendu}', {id_exp}, {id_adh});
            """
    else :
        sql=f"""
            INSERT INTO Pret (debut, duree, id_exp, id_adh) 
            VALUES ('{debut}', {duree},  {id_exp}, {id_adh});
        """
    
    cursor.execute(sql)
    # cursor.execute("""
    #         INSERT INTO Pret (debut, duree, dateRendu, id_exp, id_adh) 
    #         VALUES (%s, %s, %s, %s, %s);
    #     """, (debut, duree, dateRendu, id_exp, id_adh))
    conn.commit()
    print("Pret inséré avec succès.")
    cursor.close()
    conn.close()

def dispo_exemplaire(id_exp):
    """vérifie si l'exp est dispo et en bon état"""
    if not id_exp:
        id_exp=choixExemplaire()
    conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
    cursor = conn.cursor()
    
    
    #verifie si l'exemplaire est emprunté
    sql=f" SELECT * FROM Exemplaire  e  JOIN Pret p ON e.id=p.id_exp WHERE  (p.id_exp = {id_exp}) AND (p.dateRendu is NULL) AND (p.debut <= now())"
    cursor.execute(sql)
    result = cursor.fetchone()
    
    if result :
        print("exemplaire non disponible")
        return False
    
    #verifie l'état
    sql=f"""
            SELECT etat FROM Exemplaire e
            WHERE  (e.id = {id_exp})
        """
    
    cursor.execute(sql)
    result = cursor.fetchone()
    
    
    if result and (result[0].lower()=="bon" or result[0]=="neuf" ):           
        return True
    else:
        print("exemplaire trop abîmé")
        return False

def InsertPret():    
    id_exp = choixExemplaire()
    if not id_exp:
        return -1
    try:
        # id_adh = int(input("ID de l'adhérent : "))
        id_adh=rechercherAdherent(retournerId=True)
        id_adh=id_adh[0]
        if not dispo_exemplaire(id_exp):# si l'exp n'est pas dispo
            print("abandon : L'exemplaire n'est pas disponible ou pas en bon état.")
            return -1
        debut = choixDate("Date de début du prêt (format aaaa-mm-jj) : ")
        duree = int(input("Durée du prêt (en jours) : "))
        dateRendu = "";#choixDate("Date de retour ")
        # InsertPretSql(debut, duree, id_exp, id_adh, dateRendu)
        InsertPretSql(debut,duree,dateRendu,id_exp,id_adh)
    except Exception as e:
        print("erreur emprunt exemplaire")
        print(e)
    

def test_InsertPretSql():
    debut = input("Date de début du prêt (format aaaa-mm-jj) : ")
    duree = int(input("Durée du prêt (en jours) : "))
    id_exp = choixExemplaire()
    id_adh = int(input("ID de l'adhérent : "))
    date_rendu = input("Date de retour (format aaaa-mm-jj): ")
    InsertPretSql(debut, duree, date_rendu, id_exp, id_adh)



#Afficehr les exeamlaires exmpruntés par utilisateur
def afficher_emprunts_utilisateur(id_adh=None):
    conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
    cursor = conn.cursor()
    if id_adh is None:
        cursor.execute("""
            SELECT p.debut, p.duree, p.dateRendu, r.titre, e.etat, e.id as id_exp, id_adh
            FROM Pret p     
            JOIN Exemplaire e ON p.id_exp = e.id
            JOIN Ressources r ON e.CodeRessource = r.CodeRessource
            WHERE p.dateRendu IS NULL;
        """)
    else:
        cursor.execute("""
            SELECT p.debut, p.duree, p.dateRendu, r.titre, e.etat, e.id as id_exp, id_adh
            FROM Pret p
            JOIN Exemplaire e ON p.id_exp = e.id
            JOIN Ressources r ON e.CodeRessource = r.CodeRessource
            WHERE p.dateRendu IS NULL AND p.id_adh = %s;
         """, (id_adh,))
    emprunts = cursor.fetchall()
    if (id_adh) :
        print ("Emprunts effectués par :")
        affiche_nom_prenom(id_adh)
    else :
        print("Tous les emprunts")
        
    for emprunt in emprunts:
        print(f"Id exemplaire: {emprunt[5]},emprunteur; {nom_prenom(emprunt[6],simple=True)} Titre: {emprunt[3]}, Date de début: {emprunt[0]}, Durée: {emprunt[1]} jours, Etat de l'exemplaire: {emprunt[4]}")
    cursor.close()
    conn.close()


def demandeIdExemplaire():
    id_exp=inputEntier("entrez le numéro de l'exemplaire",min=None,max=None,boucleOnError=False)
    return id_exp

# fonction pour rendre un exemplaire
def rendre_exemplaire(id_exp):
    try:
        if not id_exp :
            id_exp = demandeIdExemplaire()
        conn=psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
        cursor = conn.cursor()
        cursor.execute("""
                SELECT p.debut, p.duree, p.dateRendu
                FROM Pret p
                WHERE p.id_exp = %s AND p.dateRendu IS NULL;
            """, (id_exp,))
        emprunt = cursor.fetchone()
        if emprunt:
            date_rendu = inputDate("Entrez la date de retour (format aaaa-mm-jj) : ")
            cursor.execute("""
                UPDATE Pret
                SET dateRendu = %s
                WHERE id_exp = %s AND dateRendu IS NULL;
            """, (date_rendu, id_exp))
            conn.commit()
            print(f"Exemplaire {id_exp} rendu avec succès à la date {date_rendu}.")
        else:
            print(f"L'exemplaire avec l'ID {id_exp} n'est pas actuellement emprunté ou déjà rendu.")
            
    except Exception as e:
        print("erreur rendre ressource")    
        print(e)
        
    cursor.close()
    conn.close()



if __name__=="__main__":
    # test_InsertPretSql()   
    afficher_emprunts_utilisateur()
    id=6 #Marie
    print(f"pret adh={id}")
    afficher_emprunts_utilisateur(6)

