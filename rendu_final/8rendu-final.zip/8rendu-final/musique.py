from ressource import *
from requeteSql import *


#atester
def InsertMusiqueSql(CodeRessource, duree):
    conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO Musique (CodeRessource, duree) 
        VALUES (%s, %s);
    """, (CodeRessource, duree))
    conn.commit()
    print("Musique insérée avec succès.")
    cursor.close()
    conn.close()
