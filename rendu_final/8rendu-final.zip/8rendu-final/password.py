
    
HOST = "localhost"

USER = "yvon"
PASSWORD = ""
DATABASE = "tp4"
