# -------------------------------------------------------------------------
# code pour ressource / exemplaire /pret /genre
# -------------------------------------------------------------------------

from requeteSql import *
from  personne import *


# -------------------------------------------------------------------------
# code pour ressource
# -------------------------------------------------------------------------




def getNextCodeRessource():
    sql = "SELECT max(CodeRessource) FROM ressources"
    res = valeurExecuteSql(sql)
    if res<0 :
        print("erreur code ressource (fonction getNextCodeRessource)")
    return res+1

def choixRessource(filtreTitre=True,titre=""):
    if filtreTitre :
        titre = input("donnez le titre (ou une partie)")
    if titre :
        sql=f"SELECT CodeRessource, titre FROM ressources WHERE titre LIKE '%{titre}%'"
    else:
        sql=f"SELECT CodeRessource,titre FROM ressources"
    choix =executeSqlSelect(sql,['id','titre'],True)
    return choix[1] #=CodeRessource

# --------- insertSql ---------------

def InsertRessourceSql(CodeRessource, titre, dateApparition, codeClassification, nomGenre, nomEditeur):
    conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
    cursor = conn.cursor()
    cursor.execute("""
            INSERT INTO Ressources (CodeRessource, titre, dateApparition, codeClassification, nomGenre, nomEditeur) 
            VALUES (%s, %s, %s, %s, %s, %s);
        """, (CodeRessource, titre, dateApparition, codeClassification, nomGenre, nomEditeur))
    conn.commit()
    print("Ressource insérée avec succès.")
    cursor.close()
    conn.close()




# --------------- input data ----------------
# demande à l'utilisateur les données puis appelle les fonctions Insert...SQL


    
def InsertRessource():
    print("Ajout d'une nouvelle ressource.")
    # CodeRessource = int(input("Entrez le Code Ressource: "))
    CodeRessource = getNextCodeRessource()
    titre = input("Entrez le titre de la ressource: ")
    # dateApparition = input("Entrez la date d'apparition (format aaaa-mm-jj): ")
    dateApparition = inputDate()
    codeClassification = int(input("Entrez le code de classification: "))
    # nomGenre = input("Entrez le genre de la ressource: ")
    nomGenre = choixGenre()
    # nomEditeur = input("Entrez l'éditeur de la ressource: ")
    nomEditeur = choixEditeur()
    InsertRessourceSql(CodeRessource, titre, dateApparition, codeClassification, nomGenre, nomEditeur)
    choix='o'
    choix= input("voulez vous ajouter un exemplaire?(o/n)").lower()
    while(choix=='o'):
        InsertExemplaire(CodeRessource)
        choix= input("voulez vous ajouter un autre exemplaire?(o/n)").lower()


#--------------------- affiche ----------------    

def afficheEmpruntParRessource():
    sql = """
        SELECT E.CodeRessource, R.titre, count(E.CodeRessource) FROM Pret as P
        JOIN vAdherent as A ON P.id_adh = A.id
        JOIN Exemplaire as E ON P.id_exp = E.id
        JOIN Ressources as R ON E.CodeRessource = R.CodeRessource
        GROUP BY (E.CodeRessource, R.titre);
        """
    
    executeSqlSelect(sql,["CodeRessource","titre","nb d'emprunts"])



# -------------------------------------------------------------------------
# code pour  exemplaire 
# -------------------------------------------------------------------------




def ExemplaireSQL( id, etat ,  CodeRessource ):
    conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
    cursor = conn.cursor()
    cursor.execute("""
            INSERT INTO Exemplaire (id, etat, CodeRessource) 
            VALUES (%s, %s, %s);
        """, (id, etat, CodeRessource))
    conn.commit()
    print("Exemplaire inséré avec succès.")
    cursor.close()
    conn.close()


def InsertExemplaire(idRess=None):
        if not idRess:
            idRess = choixRessource()
        etat = choixEtat()
        idEx=getNextCodeExemplaire()
        ExemplaireSQL(idEx, etat, idRess)


def getNextCodeExemplaire():
    sql = "SELECT max(id) FROM exemplaire"
    res = valeurExecuteSql(sql)
    if res<0 :
        print("erreur code exemplaire (fonction getNextCodeRessource)")
    return res+1


def choixEtat():
    choix='0'
    print("1.neuf")
    print("2.bon")
    print("3.abîmé")
    print("4.perdu")
    while (choix<'1' or choix>'4'):
        choix = input(choix)
    
    match choix :
        case '1': 
            return "neuf"
        case '2':
            return "bon"
        case '3':
            return "abîmé" 
        case '4':
            return "perdu"
               

def compteExemplaires():
    sql= """
    SELECT E.CodeRessource, titre ,count(*)
            FROM Exemplaire as E JOIN Ressources  as R ON E.CodeRessource=R.CodeRessource
                            LEFT JOIN Film as F ON  R.CodeRessource =F.CodeRessource
                            LEFT JOIN Musique M ON R.CodeRessource =M.CodeRessource
                            LEFT JOIN Livre L ON R.CodeRessource =L.CodeRessource
                            
                            GROUP BY (E.CodeRessource, titre );
    
    """
    
    executeSqlSelect(sql,["idRessource","titre","Nombre d'exemplaires"])





# -------------------------------------------------------------------------
# code pour pret
# -------------------------------------------------------------------------



def InsertPretSQL(debut, duree, dateRendu, id_exp, id_adh):
    conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
    cursor = conn.cursor()
    cursor.execute("""
            INSERT INTO Pret (debut, duree, dateRendu, id_exp, id_adh) 
            VALUES (%s, %s, %s, %s, %s);
        """, (debut, duree, dateRendu, id_exp, id_adh))
    conn.commit()
    print("Emprunt inséré avec succès.")
    cursor.close()
    conn.close()


def faireEmpruntSQL(id_exemplaire,id_adherent,  debut, dateRendu, duree):
    # ancienne fonction // nouvelle = dans pret.py
        conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
        cursor = conn.cursor()
        try:
            cursor.execute("""
                SELECT id_exp FROM Pret WHERE id_exp=%s 
                        AND ( (debut<=%s AND dateRendu>=%s) OR
                        (debut<=%s AND %s<=dateRendu)
                );""",(id_exemplaire, debut, dateRendu,dateRendu, debut))
            dispo=cursor.fetchone()
        except:
            dispo=False #TODO:ameliorer
        if dispo: 
            cursor.execute("""
            INSERT INTO Pret (debut, duree, id_exp, id_adh, dateRendu)
            VALUES (%s, %s, %s, %s, NULL);
        """, (debut, duree, id_exemplaire, id_adherent))
            conn.commit()
            return True
        else :
            return False

def faireEmprunt():
    id_exemplaire=int(input("id exemplaire"))
    debut=inputDate("date de debut aaaa-mm-jj")
    duree=input("duree")
    # id_adherent=int(input("id adherenet"))
    id_adherent=rechercherAdherent(retournerId=True)
    # dateRendu=inputDate("date de rendu")
    dateRendu=""
    disponible = faireEmpruntSQL(id_exemplaire,id_adherent,  debut,dateRendu, duree)
    if disponible:
        print(f"Emprunt réussi pour l'exemplaire {id_exemplaire} par l'adherent {id_adherent} pour une durée de {duree} jours.")
    else:
        print(f"Emprunt échoué. L'exemplaire {id_exemplaire} n'est pas disponible pour les dates sélectionnées.")
        
        
# def dans statistiques.py
# def afficheEmpruntParAdherent():
#     sql="""
#     SELECT   P.id_Adh, A.nom,A.prenom,count(P.id_exp) FROM Pret as P
#         JOIN vAdherent as A ON P.id_adh = A.id
#         JOIN Exemplaire as E ON P.id_exp = E.id
#         JOIN Ressources as R ON E.CodeRessource = R.CodeRessource
#         GROUP BY (P.id_Adh, A.nom,A.prenom);

#     """
#     executeSqlSelect(sql,["idAdh","nom\t","prénom\t","nb exemplaires empruntés"])   


# -------------------------------------------------------------------------
# code pour genre
# -------------------------------------------------------------------------

#-------- utiles ----------
def choixGenre():
    sql="SELECT nom FROM Genre"
    choix =executeSqlSelect(sql,None,True)
    return choix[1]


# défini dans statistique.py
# def afficheGenrePopulaire() :
#         sql="""
#         SELECT G.nom AS Genre, COUNT(Pr.id_exp) AS Nombre_Pretes
#             FROM Genre G
#             JOIN Ressources R ON G.nom = R.nomGenre
#             JOIN Exemplaire E ON R.CodeRessource = E.CodeRessource
#             JOIN Pret Pr ON E.id = Pr.id_exp
#             GROUP BY G.nom
#             ORDER BY Nombre_Pretes DESC;
#         """
#         executeSqlSelect(sql,["genre","nb emprunts"])


#------ insertSQL---------


#atester
def InsertGenreSql (nom):
    conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO Genre (nom) 
        VALUES (%s);
    """, (nom,))
    conn.commit()
    print("genre insere avec succès.")
    cursor.close()
    conn.close()
    
    
