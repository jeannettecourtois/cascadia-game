import psycopg2
import re 

from password import * 
from ressource import *
from menu import * 
from requeteSql import *
from personne import *
from film import *
from statistiques import *


# on va se limiter à (dans l'ordre d'importance):
"""

- on ajoute un film (plus tard on va gérer les autres ressources)
- on ajoute un emprunt entrer id adherent puis choix = affiche la liste des films si ressource disponible
- on rend une ressource (si retard gérer une sanction)
- on affiche la liste des emprunts en retard

ensuite :
- sous menu gérer utilisateur
    - entrer un utilisateur 
    - liste des utilisateurs / des balklistés
    (- rechercher un utilisateur)

puis :
- sous menu stats
    - afficheGenrePopulaire() 
"""


def tester_requeteInsert():
    #ajouter les fonctions à tester avec des bonnes valeurs (ex nomGenre doit exister dans la table Genre)
    #   changer CodeRessource à chaque appel ou effacer la table '\i insert.sql sous terminal psql
    InsertRessourceSql(10, "star war", "1980-01-01", 100, "Thriller", "Warner Bros")
    

# ----------- fonction à écrire et tester ----------

# --------- insertSql ---------------
# autres fonctions à ajouter 



# --------------- input data ----------------
# demande à l'utilisateur les données puis appelle les fonctions Insert...SQL
    


    
    
if __name__ == "__main__" :

   
    if (not PASSWORD) :
        conn=None
        PASSWORD = input('entrez le mot de passe pour se connecter à la base de donnée')
        while ( not conn) :
            try:
                conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
            except :
                PASSWORD = input('erreur connexion\nentrez le mot de passe pour se connecter à la base de donnée')
                conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))

        conn.close()


    idPersonne=-1 # utilisateur actuel (adherent ou personnel)
    CategoriePersonne=-1 #(ADHERENT ou PERSONNEL ou DEBUG ou -1=personne connecté)
    idAdherent=-1  #adherent activé


    idPersonne=1 # debug 
    CategoriePersonne=PERSONNEL # debug 



    # CategoriePersonne = DEBUG # afficheMenu() #debug
    choix=1
    while (True and choix!=0):
        if CategoriePersonne == -1:
            idAdherent,idPersonne,CategoriePersonne=Menu_Principal(idAdherent,idPersonne,CategoriePersonne)
        if CategoriePersonne == ADHERENT:
            idAdherent,idPersonne,CategoriePersonne=Menu_Adherent(idAdherent,idPersonne,CategoriePersonne)
        if CategoriePersonne == PERSONNEL:
            idAdherent,idPersonne,CategoriePersonne=Menu_Administrateur(idAdherent,idPersonne,CategoriePersonne)
            
        if CategoriePersonne ==DEBUG:
            idAdherent,idPersonne,CategoriePersonne=afficheMenuDebug(idAdherent,idPersonne,CategoriePersonne)
            CategoriePersonne=-1  #puis retour au mode normal
        if CategoriePersonne == QUITTER:
            print("fin de programme")
            choix=0
            
            
            
    