import psycopg2
import re

from password import * 

# ---------- fonctions de service ---------------

def inputDate(text=""):
    if not text :
        text="Entrez la date (format aaaa-mm-jj): "
    date=""
    while (not re.compile(r"\d{4}-\d{2}-\d{2}").match(date)):
        date=input(text)
    return date

def inputDuree(text=""):
    if not text :
        text="Entrez la durée (ex  2h20): "
    date=""
    while (not re.compile(r"\d{1,2}h\d{2}").match(date)):
        date=input(text).lower()
    return date
    

#------------ execution de requetes sql -----------

def executeSqlSelect(sql,nomChamp=[],retourneChoix=False,menuInsertion=False):
    """affiche les résultats d'une requète select
        si reourneChoix=True propose de choisir un enregistrement et retourne (noChoix,1erChamp) 
                                                       avec noChoix=no ligne et 1erChamp=id si  sql=SELECT id,.. 
    """
    
    listeChoix=[]
    
    
    # Connexion à la base de données PostgreSQL
    conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
    # print (conn)

    cursor = conn.cursor()
    cursor.execute(sql)
    rows = cursor.fetchall()
    if not rows:
        print ("aucun résultat")
        if retourneChoix :
            return (-1,-1)
        else:
            return -1
    i=-1
    if (retourneChoix): 
        for  i, row in enumerate(rows):
            txt=str(i)+" "
            for j,champ  in enumerate(row) :
                if (nomChamp):
                    txt+=" "+nomChamp[j]+":"
                txt+=str(champ)+" "
                # print(i,champ)
            print(txt)
            listeChoix.append(row[0]) # retournera valeur de la 1ere colonne
            # print("-"*20)
        maxChoix=i
        
    
    else :

        if (not nomChamp):
            for  row in rows:
                for i, champ  in enumerate(row) :
                    print(i,champ)
                print("-"*20)
                
        else : 
            for row in rows:
                for i,champ  in enumerate(row) :
                    print(f"{nomChamp[i]} :\t{champ}")
                print("-"*20)

    conn.close()
    
    res=0
    if (retourneChoix and maxChoix>=0):
        res=-2
        while (res<0 or res>maxChoix):
            if menuInsertion :
                res = int(input( "votre choix (-1 pour ajouter un champ)? " ))
                if res==-1 :
                    return -1
            else :
                res = int(input( "votre choix ? " ))
        return (res,listeChoix[res])
    
    return 0

def executeSqlSelectToTuple(sql,nbLigne=1):
    """ retourne une ligne résultat d'une requête sql sous forme de tuples
       ex : "select id,nom from t where id=i" => (id,nom)
       None  si non trouvé
       si nbLigne!=1 retourne tous les résultats
       
    """
    # Connexion à la base de données PostgreSQL
    conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
    # print (conn)

    cursor = conn.cursor()
    cursor.execute(sql)
    rows = cursor.fetchall()
    if not rows:
        return None
    if nbLigne==1:
        return rows[0]
    else:
        return rows
    



def valeurExecuteSql(sql,nomChamp=[],retourneChoix=False,entier=True):
    "retourne une valeur entière (si entier=True)  d'une requète select ex: req. count() max()"
    # Connexion à la base de données PostgreSQL
    conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
    # print (conn)

    try:
        cursor = conn.cursor()
        cursor.execute(sql)
        rows = cursor.fetchall()
        if entier :
            res = int(rows[0][0] )
        else:
            res = rows[0][0] 
    except :
        res=-1 if entier else ""
    
    return res
 



def executeSqlUpdate(sql):
    # Connexion à la base de données PostgreSQL
    conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
    # print (conn)
    
    try:
        cursor = conn.cursor()
        cursor.execute(sql)
        conn.commit()
    except :
        res=-1
        conn.close
        return -1
    conn.close()
    return 1
 
def getNextId(table="",nomId='id'):
    sql = f"SELECT max({nomId}) FROM {table}"
    res = valeurExecuteSql(sql)
    if res<0 :
        print("erreur fonction getNextId (table:{table}))")
    return res+1


if __name__=="__main__":
    pass
    
    # print(getNextId("utilisateur"))
    # print(valeurExecuteSql("SELECT nom FROM ville WHERE codepostal = '60610'",entier=False))