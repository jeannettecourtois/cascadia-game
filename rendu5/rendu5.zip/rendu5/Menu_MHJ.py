
def Menu_Principale():
    while True :
        print("1.Connexion")
        print("0.Quitter")
        choice=int(input("votre choix?"))
        if choice in [0,1] :
            return choice
        print("Choix invalide")

def changerAdherent():
    idAdh=input("Entrez l'id de l'adherent")
    return idAdh

def Menu_Administrateur():
    while True:
        print("1.Changer d'adherent")
        print("2.Faire un emprunt")
        print("3.Rendre une ressource")
        print("4.Creer un adherent")
        print("5.Sanctionner un adherent")
        print("6.Statistiques")
        print("0.Menu Principale")
        choix=int(input("Votre Choix?"))
        if choix==0 :
            print("retour au menu principale")
            return
        elif (1<=choix<=6):
            match choix:
                case 1:
                    id_adherent=changerAdherent()
                case 2:
                    faireEmprunt()
                case 3:
                    rendreRessource()
                case 4:
                    creerAdherent()
                case 5:
                    sanctionnerAdherent():
                case 6:
                    statistiques()
        else :
            print("Choix invalide, entrez un nouveau choix:")

def Menu_Adherent():
    while True :
        print("1.Afficher la liste des films par genre")
        print("2.Afficher les emprunts par ressource")
        print("3.fficher les emprunts par Adherent")
        print("4.Afficher le genre populaire")
        print("5.Compter les Blacklistes")
        print("6.Compter les exemplaires")
        ##..
        print("0.Menu Principale")
        choice=int(input("Votre Choix?"))
        if choix==0 :
            print("retour au menu principale")
            return
        elif (1<=choix<=6):
            match choix:
                case 1:
                    afficheGenreFilms()
                case 2:
                    afficheEmpruntParRessource()
                case 3:
                    afficheEmpruntParAdherent
                case 4:
                    afficheGenrePopulaire
                case 5:
                    compteBlackliste
                case 6:
                    compteExemplaires
                ##..
        else :
            print("Choix invalide, entrez un nouveau choix:")
