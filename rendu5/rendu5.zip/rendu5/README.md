 
creation base bibliotheque

\i create.sql

inserer des données

\i insert.sql

affichage

\i test_select.sql

python
======

password.py ajouter mot de passe , nom DB... (le mot de passe est facultatif, il sera demandé si absent)

executer tp_biblio_main.py
