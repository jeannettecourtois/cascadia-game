def InsertVilleSql(codePostal, nom, pays):
    conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO Ville (codePostal, nom, pays) 
        VALUES (%s, %s, %s);
    """, (codePostal, nom, pays))
    conn.commit()
    print("ville inseree avec succes.")
    cursor.close()
    conn.close()

def InsertAdresseSql(numero, rue, codePostal):
    conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO Adresse (numero, rue, codePostal) 
        VALUES (%s, %s, %s);
    """, (numero, rue, codePostal))
    conn.commit()
    print("Adresse inseree avec succes.")
    cursor.close()
    conn.close()

def InsertGenreSql (nom):
    conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO Genre (nom) 
        VALUES (%s);
    """, (nom,))
    conn.commit()
    print("fgenre insere avec succès.")
    cursor.close()
    conn.close()

def InsertEditeurSql(nom):
    conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO Editeur (nom) 
        VALUES (%s);
    """, (nom))
    conn.commit()
    print("editeur insere avec succès.")
    cursor.close()
    conn.close()

def InsertRessourceSql(CodeRessource, titre, dateApparition, codeClassification, nomGenre, nomEditeur):
    conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
    cursor = conn.cursor()
    cursor.execute("""
            INSERT INTO Ressources (CodeRessource, titre, dateApparition, codeClassification, nomGenre, nomEditeur) 
            VALUES (%s, %s, %s, %s, %s, %s);
        """, (CodeRessource, titre, dateApparition, codeClassification, nomGenre, nomEditeur))
    conn.commit()
    print("Ressource insérée avec succès.")
    cursor.close()
    conn.close()

def InsertFilmSql(CodeRessource, synopsis, duree, langue):
    conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
    cursor = conn.cursor()
    cursor.execute("""
            INSERT INTO Film (CodeRessource, synopsis, duree, langue) 
            VALUES (%s, %s, %s, %s);
        """, (CodeRessource, synopsis, duree, langue))
    conn.commit()
    print("film inséré avec succès.")
    cursor.close()
    conn.close()

def InsertLivreSql(CodeRessource, ISBN, resume, langue):
    conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO Livre (CodeRessource, ISBN, resume, langue) 
        VALUES (%s, %s, %s, %s);
    """, (CodeRessource, ISBN, resume, langue))
    conn.commit()
    print("livre inséré avec succès.")
    cursor.close()
    conn.close()

def InsertMusiqueSql(CodeRessource, duree):
    conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO Musique (CodeRessource, duree) 
        VALUES (%s, %s);
    """, (CodeRessource, duree))
    conn.commit()
    print("Musique inséree avec succès.")
    cursor.close()
    conn.close()

def InsertPersonneSql (id, nom, prenom, dateDeNaissance, email, telephone, numero, rue, codePostal):
    conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO Personne (id, nom, prenom, dateDeNaissance, email, telephone, numero, rue, codePostal) 
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s);
    """, (id, nom, prenom, dateDeNaissance, email, telephone, numero, rue, codePostal))
    conn.commit()
    print("personne insérée avec succès.")
    cursor.close()
    conn.close()

def InsertContributeur(id, nationalite):
    conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO Contributeur (id, nationalite) 
        VALUES (%s, %s);
    """, (id, nationalite))
    conn.commit()
    print("Contributeur inseree avec succès.")
    cursor.close()
    conn.close()


def InsertUtilisateurSql (id, login, password):
    conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO Utilisateur (id, login, password) 
        VALUES (%s, %s, %s);
    """, (id, login, password))
    conn.commit()
    print("Utilisateur insére avec succès.")
    cursor.close()
    conn.close()

def InsertAdherentSQL( id, Blackliste):
    conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
    cursor = conn.cursor()
    cursor.execute("""
            INSERT INTO Adherent (id, Blackliste) 
            VALUES (%s, %s, %s);
        """, (id, Blackliste))
    conn.commit()
    print("adherent inséré avec succès.")
    cursor.close()
    conn.close()

def InsertExemplaireSql( id, etat ,  CodeRessource):
    conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
    cursor = conn.cursor()
    cursor.execute("""
            INSERT INTO Exemplaire (id, etat, CodeRessource) 
            VALUES (%s, %s, %s);
        """, (id, etat, CodeRessource))
    conn.commit()
    print("exemplaire inséré avec succès.")
    cursor.close()
    conn.close()

def InsertPretSQL(debut, duree, dateRendu, id_exp, id_adh):
    conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
    cursor = conn.cursor()
    cursor.execute("""
            INSERT INTO Pret (debut, duree, dateRendu, id_exp, id_adh) 
            VALUES (%s, %s, %s, %s, %s);
        """, (debut, duree, dateRendu, id_exp, id_adh))
    conn.commit()
    print("Emprunt inséré avec succès.")
    cursor.close()
    conn.close()

def InsertSanctionSQL(date, duree, motif, id):
    conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
    cursor = conn.cursor()
    cursor.execute("""
            INSERT INTO Sanction (date, duree, motif, id) 
            VALUES (%s, %s, %s, %s, %s);
        """, (date, duree, motif, id))
    conn.commit()
    print("Sanction inséré avec succès.")
    cursor.close()
    conn.close()