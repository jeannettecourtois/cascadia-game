
    
HOST = "localhost"
HOST
USER = "yvon"
PASSWORD = ""
DATABASE = "tp4"
