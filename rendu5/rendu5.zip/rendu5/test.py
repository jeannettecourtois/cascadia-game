    
def test (sql):
    print ('-'*10)
    conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
    # Open a cursor to send SQL commands
    cur = conn.cursor()
    
    # sql = "SELECT name, century FROM v_philosopher"
    cur.execute(sql)
    raw = cur.fetchone()
    while raw:
        print (raw)
        raw = cur.fetchone()
