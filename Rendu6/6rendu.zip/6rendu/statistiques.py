from requeteSql import *

def print_todo():
    print("non implémenté")

def afficheGenrePopulaire() :
        sql="""
        SELECT G.nom AS Genre, COUNT(Pr.id_exp) AS Nombre_Pretes
            FROM Genre G
            JOIN Ressources R ON G.nom = R.nomGenre
            JOIN Exemplaire E ON R.CodeRessource = E.CodeRessource
            JOIN Pret Pr ON E.id = Pr.id_exp
            GROUP BY G.nom
            ORDER BY Nombre_Pretes DESC;
        """
        executeSqlSelect(sql,["genre","nb emprunts"])


def afficheEmpruntParAdherent():
    sql="""
    SELECT   P.id_Adh, A.nom,A.prenom,count(P.id_exp) FROM Pret as P
        JOIN vAdherent as A ON P.id_adh = A.id
        JOIN Exemplaire as E ON P.id_exp = E.id
        JOIN Ressources as R ON E.CodeRessource = R.CodeRessource
        GROUP BY (P.id_Adh, A.nom,A.prenom);
    """
    executeSqlSelect(sql,["idAdh","nom\t","prénom\t","nb exemplaires empruntés"])   
    
    sql="SELECT count(*) FROM adherent"
    nb_adh = valeurExecuteSql(sql)
    print(f"Nombre adhérents : {nb_adh} ")                          
    
    sql="SELECT  count(id_exp) FROM Pret "
    nb_pret = valeurExecuteSql(sql)
    print(f"Nombre emprunts : {nb_pret} ")                          
    print(f"Moyenne emprunts/adherent : {nb_pret/nb_adh} ")                          
    
    

""" 
    requetes à tester
    
    -- Nombre de ressources par genre
SELECT G.nom AS Genre, COUNT(R.CodeRessource) AS Nombre_Ressources
FROM Genre G
LEFT JOIN Ressources R ON G.nom = R.nomGenre
GROUP BY G.nom
ORDER BY Nombre_Ressources DESC;
-- Nombre de contributeurs par nationalité
SELECT C.nationalite AS Nationalité, COUNT(C.id) AS Nombre_Contributeurs
FROM Contributeur C
GROUP BY C.nationalite
ORDER BY Nombre_Contributeurs DESC;
-- Nombre d'exemplaires par état
SELECT E.etat AS Etat, COUNT(E.id) AS Nombre_Exemplaires
FROM Exemplaire E
GROUP BY E.etat
ORDER BY Nombre_Exemplaires DESC;
-- Nombre d'adhérents blacklistés par ville
SELECT V.nom AS Ville, COUNT(A.id) AS Nombre_Adherents_Blacklistes
FROM Ville V
JOIN Adresse Adr ON V.codePostal = Adr.codePostal
JOIN Personne P ON Adr.numero = P.numero AND Adr.rue = P.rue AND Adr.codePostal =
P.codePostal
JOIN Adherent A ON P.id = A.id
WHERE A.Blackliste = TRUE
GROUP BY V.nom
ORDER BY Nombre_Adherents_Blacklistes DESC;
-- Durée moyenne des prêts par adhérent
  ERREUR faire differene dates
            SELECT A.id AS ID_Adherent, P.nom, P.prenom, AVG(Pr.duree) AS Duree_Moyenne
            FROM Adherent A
            JOIN Personne P ON A.id = P.id
            JOIN Pret Pr ON A.id = Pr.id_adh
            GROUP BY A.id, P.nom, P.prenom
            ORDER BY Duree_Moyenne DESC;
-- Nombre de prêts par ressource
SELECT R.titre AS Titre_Ressource, COUNT(Pr.id_exp) AS Nombre_Pretes
FROM Ressources R
JOIN Exemplaire E ON R.CodeRessource = E.CodeRessource
JOIN Pret Pr ON E.id = Pr.id_exp
GROUP BY R.titre
ORDER BY Nombre_Pretes DESC;
-- Adhérents avec le plus de sanctions
SELECT A.id AS ID_Adherent, P.nom, P.prenom, COUNT(S.date) AS Nombre_Sanctions
FROM Adherent A
JOIN Personne P ON A.id = P.id
JOIN Sanction S ON A.id = S.id
GROUP BY A.id, P.nom, P.prenom
ORDER BY Nombre_Sanctions DESC;
-- Ressources disponibles par éditeur
SELECT E.nom AS Editeur, COUNT(R.CodeRessource) AS Nombre_Ressources
FROM editeur E
LEFT JOIN Ressources R ON E.nom = R.nomEditeur
GROUP BY E.nom
ORDER BY Nombre_Ressources DESC;
-- Nombre d'adhésions par année
SELECT YEAR(Ah.debut) AS Annee, COUNT(Ah.NoCarteAdherent) AS
Nombre_Adhesions
FROM Adhesion Ah
GROUP BY YEAR(Ah.debut)
ORDER BY Annee ASC;
-- Genres les plus populaires empruntés
SELECT G.nom AS Genre, COUNT(Pr.id_exp) AS Nombre_Pretes
FROM Genre G
JOIN Ressources R ON G.nom = R.nomGenre
JOIN Exemplaire E ON R.CodeRessource = E.CodeRessource
JOIN Pret Pr ON E.id = Pr.id_exp
GROUP BY G.nom
ORDER BY Nombre_Pretes DESC;

    
"""
    
    
if __name__== "__main__":
        afficheEmpruntParAdherent()