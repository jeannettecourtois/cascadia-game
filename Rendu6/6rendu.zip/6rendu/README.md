 
# creation base bibliotheque et initialisation 

\i create.sql

inserer des données

\i insert.sql


### affichage

\i test_select.sql

# python


password.py ajouter mot de passe , nom DB... (le mot de passe est facultatif, il sera demandé si absent)

executer tp_biblio_main.py (=version de test: seul quelques fonctions sont disponibles)


### tester : 

- au démarrage on a le menu administrateur (un membre du personnel s'est connecté)
- déconnexion + connexion d'un utilisateur (ex killer/666) -> menu limité pour utilisateur
- déconnexion + connexion d'un administrateur ex admin/admin
    menu complèt   (remarque  * = fonctionnent, sans * non implémenté ou avec bug) 

- ajouter JSON (en sql) menu 5 puis (1. afficher avant modification id=1 sera modifié) puis 4 et 1 pour afficher