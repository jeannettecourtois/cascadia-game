import psycopg2
import re 

from password import * 
from ressource import *
from menu import * 
from requeteSql import *
from personne import *
from film import *
from statistiques import *

def print_espace_menu():
    print("\n"*5)

# ------ menu pour debug -------
def afficheMenuDebug(idAdherent,idPersonne,CategoriePersonne):
    print_espace_menu()
    # choix = int( input("choix ?"))
    # return choix

    choix=-1
    fin=False
    #  while (choix != 0):
    while (not fin):
        # choix = afficheMenu() 
        
      
        while (( choix<0 or choix>7)and not fin):
            # choix = afficheMenu() 
            print("\n"*5)
            # print("1.affiche personnes")
            # print("2.affiche films")
            # print("3.compteExemplaires")
            # print("4.affiche films par genre")
            # print("5.affiche Emprunt Par Adherent")
            # print("6.affiche Emprunt Par Ressource")
            # print("7.compte Blacklisté")
            # print("0.quitter")
            
            
            print("1.affiche personnes+adresse Json")
            print("2.affiche films")
            print("3.test requete insert")
            print("4.---> test JSON : requete insert JSON")
            print("0.retour menu principal")
            
            choix = int( input("choix ?"))    
            match choix :
                
                case 1 :  
                    executeSqlSelect("SELECT * FROM Personne") 
                case 2:
                    executeSqlSelect("SELECT titre,nomGenre, synopsis FROM vFilm",["titre film","genre\t","synopsis"])   
                case 3:
                    # tester_requeteInsert()
                    # res=choixGenre()
                    # getCodeRessource()
                    # inputDate()
                    # res=choixEditeur()
                    # InsertRessource()
                    # InsertFilm(menuAjouterEditeur=True)
                    # InsertEditeur()
                    # InsertExemplaire()
                    id=choixRessource(True)
                    print(f"id={id}")
                    
                #     compteExemplaires()
                case 4:
                    # afficheGenreFilms()
                    sql="""UPDATE Personne Set adresse_json='{"numero": "20",\
                        "rue": "Rue de Roger", "codePostal": "60200"}' where id=1;"""
                    print(f"execute sql={sql}")
                    executeSqlUpdate(sql)
                # case 5:
                #     afficheEmpruntParAdherent()
                # case 6:
                #     afficheEmpruntParRessource()
                # case 7:
                #     compteBlackliste()
                # case 8:    
                #     afficheGenrePopulaire() 
                
                case 0:
                    fin=True  
                    return(idAdherent,idPersonne,CategoriePersonne)
                
            choix=-1
            # if (not fin):
            #     input("tapez entree")

def print_todo():
    print("non implémenté")

def Menu_Administrateur(idAdherent,idPersonne,CategoriePersonne):
    print_espace_menu()
 
    while True:
        print("1.Gérer les adherents*")
        print("2.Faire un emprunt (à finir)")
        print("3.Rendre une ressource")
        print("4.affiche Emprunts*")
        print("5. -->JSon (menu debug /TEST)")
        print("6.Statistiques*")
        print("7.Gérer les ressources*")
        print("0.déconnexion/Menu Principal")
        try :
            choix=int(input("Votre Choix?"))
        except :
            print("entrez un nombre SVP")
        print_espace_menu()
        match choix:
            case 0:
                print("déconnecté")
                CategoriePersonne=-1
                idPersonne=-1
                return  (idAdherent,idPersonne,CategoriePersonne)

            case 1:
                #id_adherent, _ = changerAdherent() # on ne garde que id_adherent
                Menu_GestionAdherent(idAdherent,idPersonne,CategoriePersonne)
                
            case 2:
                faireEmprunt()
                
            case 3:
                # rendreRessource()
                print_todo()
            case 4:
                # creerAdherent()
                afficheEmpruntParRessource()
            case 5:
                afficheMenuDebug(idAdherent,idPersonne,CategoriePersonne)
                # sanctionnerAdherent():
                print_todo()
            case 6:
                # statistiques()
                Menu_Statistiques(idAdherent,idPersonne,CategoriePersonne)
                # print_todo()
            case 7:
                Menu_GererRessource(idAdherent,idPersonne,CategoriePersonne) 

            case _:
                print("Choix invalide, entrez un nouveau choix:")

def Menu_Adherent(idAdherent,idPersonne,CategoriePersonne):
    print_espace_menu()

    while True :
        print("1.Afficher la liste des films par genre (à faire)")
        # print("2.Afficher les emprunts par ressource")
        # print("3.Afficher les emprunts par Adherent")
        print("4.Afficher le genre populaire (à faire)")
        # print("5.Compter les Blacklistes")
        # print("6.Compter les exemplaires")
        ##..
        print("0.Menu Principal")
        try :
            choix=int(input("Votre Choix?"))
        except :
            print("entrez un nombre SVP")
        
        if choix==0 :
            print("déconnexion / retour au menu principal")
            CategoriePersonne=-1
            idPersonne=-1
            return (idAdherent,idPersonne,CategoriePersonne)
        elif (1<=choix<=6):
            match choix:
                case 1:
                    # afficheGenreFilms()
                    print_todo()
                case 2:
                    # afficheEmpruntParRessource()
                    print_todo()
                case 3:
                    # afficheEmpruntParAdherent()
                    print_todo()
                case 4:
                    # afficheGenrePopulaire()
                    print_todo()
                case 5:
                    # compteBlackliste()
                    print_todo()
                case 6:
                    # compteExemplaires()
                    print_todo()
                
        else :
            print("Choix invalide, entrez un nouveau choix:")


def Menu_Principal(idAdherent,idPersonne,CategoriePersonne):
    print_espace_menu()
  
    while True :
        print("1.Connexion")
        print("0.Quitter")
        try :
            choix=int(input("Votre Choix?"))
        except :
            print("entrez un nombre SVP")
           
        match choix:
            case 0: 
                return (idAdherent,idPersonne,QUITTER)
            case 1 :
                # print_todo()
                # id,CategoriePersonne = changerAdherent() 
                id,CategoriePersonne = login() 
                if (CategoriePersonne==ADHERENT) :
                    idAdherent= id
                elif (CategoriePersonne==PERSONNEL):
                    idPersonne = id
                elif (id<0):
                    print("\n ERREUR: erreur de login ou de mot de passe.\n")
                return (idAdherent,idPersonne,CategoriePersonne)
            case _ :     
                print("Choix invalide")


def Menu_Statistiques(idAdherent,idPersonne,CategoriePersonne):
    print_espace_menu()
  
    while True :
        print("1.genres populaires")
        print("2.nombre d'emprunts par adherent")
        print("0.Quitter")
        try :
            choix=int(input("Votre Choix?"))
        except :
            print("entrez un nombre SVP")
           
        match choix:
            case 0: 
                return (idAdherent,idPersonne,QUITTER)
            case 1 :
                afficheGenrePopulaire()
            case 2 :
                # afficheEmpruntParAdherent()
                afficheEmpruntParAdherent()
            case _ :     
                print("Choix invalide")


def Menu_GestionAdherent(idAdherent,idPersonne,CategoriePersonne):
    print_espace_menu()
    while True :
        print("1.changer d'adhérent")
        print("2.rechercher adhérent*")
        print("3.Creer un adherent*")
        print("4.Sanctionner un adherent*")
        
        print("0.retour au menu principal")
        try :
            choix=int(input("Votre Choix?"))
        except :
            print("\n---------entrez un nombre SVP-----")
            choix=-1
           
        match choix:
            case 0: 
                return (idAdherent,idPersonne,QUITTER)
            case 2 :
                id_adherent, _ = changerAdherent() # on ne garde que id_adherent
            case 1 :
                id, typeUtil = rechercherAdherent()
                if id>=0:
                    id_adherent = id
                    idPersonne = typeUtil
                # afficheEmpruntParAdherent()
                # afficheEmpruntParAdherent()
            case 3 :
                 creerAdherent()
                
            case 4 :
                sanctionnerAdherent(idAdherent)
                
                
                
            case _ :     
                print("\nChoix invalide\n")


def Menu_GererRessource(idAdherent,idPersonne,CategoriePersonne):
    print_espace_menu()
    while True :
        print("1.ajouter un film*")
        print("2.rechercher un film (<-à faire)")
        print("3.affiche les genres de films*")
        print("4.affiche tous les films*")
        # print("5.inserer ressource")
        print("0.retour au menu principal")
        try :
            choix=int(input("Votre Choix?"))
        except :
            print("entrez un nombre SVP")
           
        match choix:
            case 0: 
                return (idAdherent,idPersonne,QUITTER)
            case 1 :
                InsertFilm(True)
            case 2 :
                rechercherFilm()
                # afficheEmpruntParAdherent()
                # afficheEmpruntParAdherent()
            case 3:
                afficheGenreFilms()
            case 4:
                afficheTousLesFilms()
                
            case _ :     
                print("Choix invalide")




if __name__== "__main__":
        Menu_Administrateur(1,PERSONNEL,2)
        
        # Menu_Principal(-1,-1,-1)
        