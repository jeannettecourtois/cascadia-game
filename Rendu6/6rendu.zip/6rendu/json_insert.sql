DELETE FROM Adresse;
DELETE FROM Personne;
DELETE  FROM Ville;

INSERT INTO Ville (codePostal, nom, pays)
VALUES ('60200', 'compiegne', 'France');

INSERT INTO Adresse (numero, rue, codePostal)
VALUES ('20', 'Rue de Roger', '60200');

INSERT INTO Adresse (numero, rue, codePostal)
VALUES ('21', 'Rue de lageane', '60200');

INSERT INTO Personne (id, nom, prenom, dateDeNaissance, email, telephone, adresse_json)
VALUES (1, 'jilani', 'amine', '2000-06-20', 'amine.jilani@example.com', '0612345678',
        '{"numero": "20", "rue": "Rue de Roger", "codePostal": "60200"}');

INSERT INTO Personne (id, nom, prenom, dateDeNaissance, email, telephone, adresse_json)
VALUES (2, 'cris', 'rol', '1999-06-20', 'cirs.roli@example.com', '0612345678',
        '{"numero": "21", "rue": "Rue de lageane", "codePostal": "60200"}');

        
UPDATE Personne Set adresse_json='{"numero": "20", "rue": "Rue de Roger", "codePostal": "60200"}' where id=1;
