from ressource import *
from requeteSql import *

def InsertFilmSql(CodeRessource, synopsis, duree, langue):
    conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
    cursor = conn.cursor()
    cursor.execute("""
            INSERT INTO Film (CodeRessource, synopsis, duree, langue) 
            VALUES (%s, %s, %s, %s);
        """, (CodeRessource, synopsis, duree, langue))
    conn.commit()
    print("Film inséré avec succès.")
    cursor.close()
    conn.close()



# --------------- input data ----------------
# demande à l'utilisateur les données puis appelle les fonctions Insert...SQL




def InsertFilm(menuAjouterEditeur=False):
    print("Ajout d'un nouveau film.")
    # CodeRessource = int(input("Code ressource: "))
    CodeRessource = getNextCodeRessource()
    titre = input("Titre: ")
    # dateApparition = input("Date d'apparition (format aaaa-mm-jj): ")
    dateApparition = inputDate("date de sortie (format aaaa-mm-jj):")
    codeClassification = int(input("Code de classification: "))
    # nomGenre = input("Genre: ")
    nomGenre = choixGenre()
    # nomEditeur = input("Éditeur: ")
    nomEditeur = choixEditeur(menuAjouterEditeur)
    synopsis = input("Synopsis: ")
    # duree = input("Durée: ()")
    duree = inputDuree()
    langue = input("Langue: ")
    InsertRessourceSql(CodeRessource, titre, dateApparition, codeClassification, nomGenre, nomEditeur)
    InsertFilmSql(CodeRessource, synopsis, duree, langue)


def rechercherFilm(): #TODO:rechercherFilm()
    pass

#--------------------- affiche ----------------

def afficheGenreFilms():
    sql="""SELECT nomGenre ,count(nomGenre) 
                FROM vFilm
                GROUP BY nomGenre"""
    executeSqlSelect(sql,["genre","nombre de films"])   


def afficheTousLesFilms():
    sql="""SELECT titre ,dateapparition,nomediteur ,synopsis
                FROM vFilm
                ORDER BY titre"""
    executeSqlSelect(sql,["titre","date de sortie","Produit par","synopsis"])   


