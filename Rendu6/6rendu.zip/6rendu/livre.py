from ressource import *
from requeteSql import *


#atester
def InsertLivreSql(CodeRessource, ISBN, resume, langue):
    conn = psycopg2.connect("host=%s dbname=%s user=%s password=%s" % (HOST, DATABASE, USER, PASSWORD))
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO Livre (CodeRessource, ISBN, resume, langue) 
        VALUES (%s, %s, %s, %s);
    """, (CodeRessource, ISBN, resume, langue))
    conn.commit()
    print("livre inséré avec succès.")
    cursor.close()
    conn.close()
    